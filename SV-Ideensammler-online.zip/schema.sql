-- SV IDEENSAMMLER: Datenbank + Sicherheit
create table if not exists public.ideas (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 120),
  description text not null check (char_length(description) between 1 and 1000),
  category text not null,
  author text not null default 'Anonym',
  likes integer not null default 0 check (likes >= 0),
  read boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.ideas enable row level security;

-- Schüler dürfen Vorschläge lesen und neue Vorschläge erstellen.
drop policy if exists "public read ideas" on public.ideas;
create policy "public read ideas" on public.ideas
for select to anon, authenticated using (true);

drop policy if exists "public create ideas" on public.ideas;
create policy "public create ideas" on public.ideas
for insert to anon, authenticated with check (true);

-- Likes dürfen öffentlich erhöht werden. Die App verhindert zusätzlich doppelte Likes pro Browser.
drop policy if exists "public like ideas" on public.ideas;
create policy "public like ideas" on public.ideas
for update to anon, authenticated
using (true)
with check (
  likes >= 0
);

-- SV-Verwaltung: Nur eingeloggte Nutzer dürfen lesen/ändern/löschen.
-- WICHTIG: Für den echten Schulbetrieb sollte der Zugriff zusätzlich über
-- eine Admin-Rolle/allowlist eingeschränkt werden. Diese Basisversion nutzt Login als Schutz.
drop policy if exists "authenticated update ideas" on public.ideas;
create policy "authenticated update ideas" on public.ideas
for update to authenticated using (true) with check (true);

drop policy if exists "authenticated delete ideas" on public.ideas;
create policy "authenticated delete ideas" on public.ideas
for delete to authenticated using (true);

-- Hinweis: Die beiden UPDATE-Policies überschneiden sich absichtlich,
-- damit Likes auch ohne Login funktionieren. Für einen produktiven Betrieb
-- sollte Likes über eine eigene likes-Tabelle geregelt werden.
